# ECS129_Project
# Authors: Bardia Ghayoumi, Mira Mastoras, Abby Saenz

# To compile the code: 
"python3 KnotAlgorithm.py 1yvel_original.txt"

# Replace "1yvel_original.txt" with any protein file name

# Ensure the file with the amino acid coordinates are in the directory
# as both KnotAlgorithm.py and Geometry3D.py

